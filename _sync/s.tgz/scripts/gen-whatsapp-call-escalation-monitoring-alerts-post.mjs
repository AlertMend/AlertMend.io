import path from 'path'
import { fileURLToPath } from 'url'
import {
  AUTHOR_CRED_CSS,
  BLOG_SIGNUP_HANDLER_JS,
  CHROME_INLINE_CSS,
  SITE_URL,
  buildNavHtml,
  buildSidebarHtml,
  calendlyUrl,
  esc,
  getRelatedPosts,
  writeStaticBlogOutputs,
} from './static-blog-shared.mjs'

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')

const slug = 'whatsapp-call-escalation-monitoring-alerts'
const title = 'WhatsApp + Call Escalation for Alerts'
const h1 = 'Set Up WhatsApp + Phone Call Escalation for Your Existing Monitoring Alerts'
const description = 'Add WhatsApp and phone call escalation to Datadog log monitors, Prometheus, Grafana, CloudWatch, and existing monitoring alerts without replacing your stack.'
const publishedDate = '2026-07-13'
const modifiedDate = '2026-07-13'
const category = 'Incident Response'
const seoKeywords = [
  'WhatsApp alert escalation',
  'WhatsApp alerts for monitoring',
  'phone call escalation for alerts',
  'call escalation for monitoring alerts',
  'on-call escalation path',
  'on-call management WhatsApp',
  'monitoring alert escalation',
  'alert escalation policy',
  'incident escalation workflow',
  'automated incident escalation',
  'Grafana WhatsApp alerts',
  'Grafana phone call alerts',
  'Prometheus Alertmanager escalation',
  'Prometheus Alertmanager phone call',
  'Datadog webhook escalation',
  'Datadog log monitor escalation',
  'Datadog log alerts WhatsApp',
  'Datadog log monitor phone call',
  'Datadog phone call alerts',
  'CloudWatch alarm escalation',
  'CloudWatch Logs alarm escalation',
  'CloudWatch phone call alerts',
  'Grafana Loki alert escalation',
  'Elastic alert escalation',
  'OpenSearch alert escalation',
  'New Relic alert escalation',
  'existing log monitor escalation',
  'webhook alert escalation',
  'WhatsApp incident alerts',
  'critical alert phone call',
  'AlertMend WhatsApp escalation',
  'AlertMend call escalation',
]
const keywords = seoKeywords.join(', ')
const canonical = `${SITE_URL}/blog/${slug}`
const calendly = calendlyUrl(slug)
const related = getRelatedPosts(slug, category)
const heroImage = `${SITE_URL}/assets/${slug}/hero.svg`
const dineshLinkedin = 'https://www.linkedin.com/in/dineshagrawal85/'
const author = {
  name: 'Dinesh Agrawal',
  role: 'AI Agent Automation Expert',
  linkedin: dineshLinkedin,
}

const faq = [
  {
    q: 'What is WhatsApp alert escalation?',
    a: 'WhatsApp alert escalation means sending an important monitoring alert to the right responder on WhatsApp with service, impact, runbook, and acknowledgment context. For urgent incidents, it should be paired with a phone call fallback if nobody acknowledges quickly.',
  },
  {
    q: 'Can it work with my existing log monitor in Datadog?',
    a: 'Yes. A Datadog log monitor can stay exactly where it is. Send the log monitor alert through a Datadog webhook or notification route, then the escalation layer can add the owner, service, severity, runbook, WhatsApp message, phone call fallback, acknowledgment timeout, and audit trail.',
  },
  {
    q: 'Can it work with Grafana, Prometheus, CloudWatch, Elastic, New Relic, or my custom alerting tool?',
    a: 'Yes. The alert source can be Grafana, Prometheus Alertmanager, CloudWatch alarms, CloudWatch Logs metric filters, Elastic/OpenSearch alerting, New Relic alerts, uptime monitors, cron jobs, CI jobs, or a custom webhook. The escalation pattern is the same: send the alert payload in, route by owner and severity, then use WhatsApp and calls only when the incident deserves it.',
  },
  {
    q: 'How do I send Grafana alerts to WhatsApp?',
    a: 'Use Grafana notification policies and contact points to send selected alerts to a webhook-based escalation layer. That layer can format the Grafana alert, add ownership and runbook context, send a WhatsApp message, and start a call if the alert is critical or unacknowledged.',
  },
  {
    q: 'Can Prometheus Alertmanager trigger phone calls?',
    a: 'Alertmanager can route alerts to receivers such as webhooks. To trigger phone calls, send only high-urgency routes from Alertmanager to an escalation service that owns the call policy, acknowledgment timeout, fallback person, and audit trail.',
  },
  {
    q: 'How do I add call escalation to Datadog alerts?',
    a: 'Use Datadog webhooks for the monitors that represent real production impact. The webhook payload should include service, severity, environment, monitor URL, and team owner, then the escalation layer can decide who gets WhatsApp, who gets called, and when to fallback.',
  },
  {
    q: 'How do I call someone from an AWS CloudWatch alarm?',
    a: 'A common pattern is CloudWatch alarm action to SNS or webhook, then an escalation layer handles the phone call. Keep CloudWatch responsible for detecting the alarm, and let the escalation policy decide whether the alert deserves WhatsApp, a call, or only a ticket.',
  },
  {
    q: 'Which alerts should trigger a phone call?',
    a: 'Phone calls should be reserved for urgent, customer-impacting, time-sensitive incidents: production outage, payment path down, database unavailable, major error-rate spike, security-critical signal, or any unacknowledged P1 after a short wait.',
  },
  {
    q: 'When should alerts go to WhatsApp instead of calls?',
    a: 'WhatsApp works well for high-context escalation: P2 incidents, early warning, on-call handoff, approval requests, and P1 context before or alongside a call. It is also useful where teams naturally respond faster on WhatsApp than email or chat.',
  },
  {
    q: 'Can I add WhatsApp and phone call escalation without replacing Grafana, Prometheus, Datadog, or CloudWatch?',
    a: 'Yes. Keep the existing monitoring tool as the signal source. Send actionable alerts to an escalation layer through webhook, email, SNS, or API, then route by severity, owner, schedule, acknowledgment state, and business impact.',
  },
  {
    q: 'How do I avoid waking people for noisy alerts?',
    a: 'Use grouping, deduplication, mute windows, composite alerts, ownership labels, and escalation delay. Do not call on every metric threshold. Call only when the alert has a clear owner, impact, urgency, and no acknowledgment.',
  },
  {
    q: 'What should be inside a good WhatsApp incident alert?',
    a: 'Include service, environment, impact, severity, alert source, when it started, owner, runbook link, recent deploy or change context, acknowledgment options, and the next escalation deadline.',
  },
  {
    q: 'Can AlertMend send WhatsApp alerts and call the on-call engineer?',
    a: 'AlertMend can sit beside your existing monitoring tools and route actionable incidents into WhatsApp, phone call escalation, team channels, approvals, and runbooks where configured. The goal is not to replace dashboards; it is to make sure important alerts reach the right human and, when safe, trigger the right automation.',
  },
  {
    q: 'Do I still need PagerDuty or Opsgenie if I add WhatsApp and call escalation?',
    a: 'It depends on your workflow. Some teams use AlertMend beside PagerDuty or Opsgenie first, especially when they want WhatsApp context, infrastructure-aware routing, approved runbooks, and automated recovery on top of existing schedules.',
  },
]

const howToSteps = [
  { name: 'Choose the alert sources', text: 'Select Prometheus Alertmanager, Grafana, Datadog, CloudWatch, uptime monitors, or custom tools that already detect important incidents.' },
  { name: 'Create an escalation intake', text: 'Send actionable alerts into a webhook, email, SNS, or API endpoint with service, owner, severity, and dedupe key.' },
  { name: 'Define WhatsApp and call policies', text: 'Use WhatsApp for context and acknowledgment, and phone calls for P1 or unacknowledged incidents.' },
  { name: 'Test with safe drills', text: 'Run test alerts, verify routing, acknowledge paths, fallback timing, and post-incident audit before enabling production paging.' },
]

const blogPosting = {
  '@context': 'https://schema.org',
  '@type': 'BlogPosting',
  headline: h1,
  description,
  keywords,
  image: heroImage,
  datePublished: publishedDate,
  dateModified: modifiedDate,
  author: {
    '@type': 'Person',
    name: author.name,
    jobTitle: author.role,
    url: author.linkedin,
    sameAs: [author.linkedin],
  },
  publisher: {
    '@type': 'Organization',
    name: 'AlertMend AI',
    logo: {
      '@type': 'ImageObject',
      url: `${SITE_URL}/logos/alertmend-logo.svg`,
    },
  },
  mainEntityOfPage: {
    '@type': 'WebPage',
    '@id': canonical,
  },
}

const howToJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'HowTo',
  name: 'How to set up WhatsApp and phone call escalation for monitoring alerts',
  description,
  step: howToSteps.map((step, index) => ({
    '@type': 'HowToStep',
    position: index + 1,
    name: step.name,
    text: step.text,
  })),
}

const faqJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faq.map((item) => ({
    '@type': 'Question',
    name: item.q,
    acceptedAnswer: {
      '@type': 'Answer',
      text: item.a,
    },
  })),
}

function authorCard() {
  return `
  <section class="authorBioCard" aria-label="About the author">
    <img src="/logos/dinesh.jpeg" alt="${esc(author.name)}" width="128" height="128" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
    <div class="authorBioFallback" aria-hidden="true">DA</div>
    <div class="authorBioContent">
      <h3>${esc(author.name)}</h3>
      <p class="authorBioRole">AI Agent Automation Expert</p>
      <div class="authorBioText">
        <p>Dinesh is a software engineer and entrepreneur focused on AI-agent automation for infrastructure operations.</p>
        <p>Previously at Polymer Search and Roambee, and Co-Founder of FutureApp e-schools, he works on turning noisy production alerts into safe, auditable workflows: escalation routing, WhatsApp and phone call handoff, runbooks, and self-healing automation.</p>
      </div>
      <a class="authorBioLink" href="${author.linkedin}" target="_blank" rel="noopener noreferrer" aria-label="${esc(author.name)} on LinkedIn">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14zM8.34 18V9.94H5.67V18h2.67zM7 8.76a1.55 1.55 0 1 0 0-3.1 1.55 1.55 0 0 0 0 3.1zM18.34 18v-4.42c0-2.37-1.27-3.47-2.96-3.47-1.36 0-1.97.75-2.31 1.28V9.94h-2.67V18h2.67v-4.5c0-.24.02-.48.09-.65.19-.48.63-.98 1.36-.98.96 0 1.35.73 1.35 1.8V18h2.82z"/></svg>
        <span>LinkedIn</span>
      </a>
    </div>
  </section>`
}

function faqHtml() {
  return faq.map((item, index) => `
    <div class="faqItem">
      <button class="faqQuestion" type="button" aria-expanded="${index === 0 ? 'true' : 'false'}">
        <span>${esc(item.q)}</span>
        <svg class="faqChevron${index === 0 ? ' faqChevronOpen' : ''}" width="18" height="18" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <div class="faqAnswer" ${index === 0 ? '' : 'hidden'}>${esc(item.a)}</div>
    </div>`).join('')
}

function icon(name) {
  const icons = {
    alert: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 9v4m0 4h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    bell: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Zm-8.27 13a2.5 2.5 0 0 0 4.54 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    book: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 4.5A2.5 2.5 0 0 1 6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    calendar: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 2v4m8-4v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    call: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.77.63 2.61a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6.27 6.27l1.29-1.29a2 2 0 0 1 2.11-.45c.84.3 1.71.51 2.61.63A2 2 0 0 1 22 16.92Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    chat: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5A8.48 8.48 0 0 1 21 11v.5Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    check: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 6 9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    clock: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/><path d="M12 7v5l3 2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    cloud: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M17.5 19H7a5 5 0 1 1 .84-9.93A6.5 6.5 0 0 1 20 11.5 3.75 3.75 0 0 1 17.5 19Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    graph: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 19V5m0 14h16M8 16l3-4 3 2 5-7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    inbox: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M22 12h-6l-2 3h-4l-2-3H2M5.45 5h13.1L22 12v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6l3.45-7Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    monitor: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 5h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Zm8 13v4m-4 0h8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    route: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="6" cy="6" r="3" stroke="currentColor" stroke-width="1.8"/><circle cx="18" cy="18" r="3" stroke="currentColor" stroke-width="1.8"/><path d="M9 6h4a5 5 0 0 1 0 10H9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="m11 13-3 3 3 3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    shield: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="m9 12 2 2 4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    tag: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.59 13.41 11 3.83A2 2 0 0 0 9.59 3H4a1 1 0 0 0-1 1v5.59A2 2 0 0 0 3.83 11l9.58 9.59a2 2 0 0 0 2.83 0l4.35-4.35a2 2 0 0 0 0-2.83Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.5 7.5h.01" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
    test: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M9 3h6M10 3v5l-5.2 8.7A3 3 0 0 0 7.37 21h9.26a3 3 0 0 0 2.57-4.3L14 8V3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 15h8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    webhook: '<svg class="iconSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M18 16.5a3.5 3.5 0 1 1-2.84 5.55M6 7.5a3.5 3.5 0 1 1 3.44-4.14M12 12a3.5 3.5 0 1 1 0-7M8.7 8.2l2 2.1m2.6 2.7 2.5 2.7m-7.7.2-2.4 1.4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    whatsapp: '<svg class="iconSvg whatsappSvg" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12.04 3.5a8.46 8.46 0 0 0-7.2 12.9L3.8 20.2l3.9-1a8.46 8.46 0 1 0 4.34-15.7Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.75 8.65c.16-.35.33-.36.49-.36h.41c.13 0 .31.05.47.36.16.31.54 1.07.59 1.15.05.08.08.18.02.29-.06.11-.1.18-.2.28l-.3.33c-.1.1-.2.22-.09.42.11.2.48.8 1.03 1.3.71.64 1.3.84 1.5.94.2.1.32.08.44-.05.13-.14.5-.58.63-.78.13-.2.27-.17.45-.1.18.06 1.13.53 1.32.63.2.1.33.15.38.24.05.08.05.48-.11.94-.16.46-.92.89-1.28.93-.33.04-.75.06-1.2-.08-.28-.08-.63-.2-1.08-.4-1.9-.82-3.14-2.72-3.24-2.85-.1-.13-.77-1.02-.77-1.95s.49-1.38.54-1.46Z" fill="currentColor"/></svg>',
  }
  return icons[name] || icons.bell
}

const content = `
<header class="article-header article-header--cred">
  <h1>${esc(h1)}</h1>
  <p class="articleSubtitle">${esc(description)}</p>
  <div class="writerByline" aria-label="Article author">
    <img src="/logos/dinesh.jpeg" alt="${esc(author.name)}" width="44" height="44" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
    <div class="writerFallback" aria-hidden="true">DA</div>
    <div>
      <a href="${author.linkedin}" target="_blank" rel="noopener noreferrer">${esc(author.name)}</a>
      <p class="writerExpertLine">AI-agent automation expert focused on cloud infrastructure, alert escalation, and self-healing operations.</p>
      <p class="bylineMeta">${icon('calendar')}<span>${esc(publishedDate)}</span><span class="metaDot">•</span>${icon('tag')}<span>${esc(category)}</span></p>
    </div>
  </div>
</header>
<div class="proofStrip" aria-label="Article verification">
  <strong><span class="proofIcon">${icon('check')}</span> Works beside existing monitoring tools</strong>
  <span class="dot">•</span>
  <span>Last reviewed ${modifiedDate}</span>
  <span class="dot">•</span>
  <span>Sources cited</span>
</div>

<article class="escalationArticle article-content">
  <section class="heroPanel" id="answer">
    <div class="heroGrid">
      <div class="answerCard">
        <span class="eyebrow">The architecture</span>
        <h2>Keep your monitoring. Add a real wake-up path.</h2>
        <p>Your existing log monitor, metric monitor, uptime check, or alerting rule should keep detecting the problem. The missing layer is often escalation: who gets WhatsApp, who gets a phone call, how long before fallback, and what context they receive.</p>
        <p>The practical pattern is simple: <strong>alert source → escalation router → WhatsApp + call policy → acknowledgment + audit</strong>.</p>
        <div class="channelBadges" aria-label="Escalation channels">
          <span class="channelBadge channelBadgeWhatsapp">${icon('whatsapp')} WhatsApp escalation</span>
          <span class="channelBadge channelBadgeCall">${icon('call')} Phone call fallback</span>
        </div>
        <div class="commandStack" aria-label="Escalation design fields">
          <div class="commandLine"><code>service=checkout</code><span>owner</span></div>
          <div class="commandLine"><code>severity=critical</code><span>urgency</span></div>
          <div class="commandLine"><code>dedupe_key=checkout-5xx</code><span>noise control</span></div>
          <div class="commandLine"><code>runbook=/fix-checkout-api</code><span>next action</span></div>
        </div>
      </div>
      <div class="trustGraphic" aria-label="Escalation flow">
        <div class="miniTerminal">
          <div class="terminalChrome"><span></span><span></span><span></span></div>
          <div class="terminalBody">
            <div><span class="muted">$</span> alert fires</div>
            <div>Grafana / Datadog / Alertmanager</div>
            <div class="error">P1 checkout API down</div>
          </div>
        </div>
        <div class="trustPath">
          <div class="trustNode"><span class="nodeIcon">${icon('bell')}</span><strong>Alert</strong><span>existing tool</span></div>
          <div class="trustArrow">→</div>
          <div class="trustNode whatsappNode"><span class="nodeIcon">${icon('whatsapp')}</span><strong>WhatsApp</strong><span>context + ack</span></div>
          <div class="trustArrow">→</div>
          <div class="trustNode callNode"><span class="nodeIcon">${icon('call')}</span><strong>Call</strong><span>if no ack</span></div>
        </div>
      </div>
    </div>
  </section>

  <nav class="tocPills" aria-label="On this page">
    <a href="#importance">Importance</a>
    <a href="#setups">Setups</a>
    <a href="#why">Why</a>
    <a href="#policy">Policy</a>
    <a href="#decision-table">Decision table</a>
    <a href="#template">Template</a>
    <a href="#tools">Existing tools</a>
    <a href="#message">Message</a>
    <a href="#mistakes">Mistakes</a>
    <a href="#testing">Testing</a>
    <a href="#automation">Lightweight tool</a>
    <a href="#sources">Sources</a>
    <a href="#faq">FAQ</a>
  </nav>

  <section class="sectionBlock importanceBlock" id="importance">
    <span class="eyebrow">Why this matters</span>
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('alert')}</span>Monitoring only helps if someone acts in time</h2>
    <p class="bodyText">A dashboard can show the outage perfectly and still fail the business. The real question is: did the right person receive the alert, understand the impact, acknowledge it, and start the fix before customers noticed?</p>
    <div class="importanceGrid">
      <div class="importanceCard">
        <div class="importanceIcon importanceIconDanger">${icon('clock')}</div>
        <h3>Every missed minute compounds</h3>
        <p>For P1 incidents, the cost is usually not the first alert. It is the silent gap after the alert: no owner, no acknowledgment, no fallback, and no clear next step.</p>
      </div>
      <div class="importanceCard">
        <div class="importanceIcon importanceIconWhatsapp">${icon('whatsapp')}</div>
        <h3>WhatsApp carries context fast</h3>
        <p>WhatsApp is useful when the on-call person needs the service, impact, runbook, deploy context, and acknowledge buttons in one place instead of digging through dashboards.</p>
      </div>
      <div class="importanceCard">
        <div class="importanceIcon importanceIconCall">${icon('call')}</div>
        <h3>Calls break through when it is urgent</h3>
        <p>Critical alerts should not quietly wait in email or chat. A call is the escalation layer for customer-impacting incidents and missed acknowledgments.</p>
      </div>
      <div class="importanceCard">
        <div class="importanceIcon importanceIconAudit">${icon('shield')}</div>
        <h3>Escalation creates accountability</h3>
        <p>With ack, fallback, audit, and runbook links, teams can see who was notified, when they responded, what action was taken, and what should be automated next.</p>
      </div>
    </div>
    <div class="beforeAfterPanel" aria-label="Before and after escalation">
      <div>
        <span class="beforeLabel">Without escalation</span>
        <p>Alert fires → notification is missed → Slack thread starts late → wrong owner joins → manual triage begins.</p>
      </div>
      <div class="beforeAfterArrow">→</div>
      <div>
        <span class="afterLabel">With WhatsApp + call escalation</span>
        <p>Alert fires → owner gets context → call fallback if no ack → runbook attached → action and audit are recorded.</p>
      </div>
    </div>
  </section>

  <section class="sectionBlock" id="setups">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('webhook')}</span>Common escalation setups this guide covers</h2>
    <p class="bodyText">Different teams search for this problem in different ways. The underlying need is the same: take alerts from the monitoring tool you already trust, then add WhatsApp context, phone call fallback, owner routing, acknowledgment, and audit.</p>
    <div class="compatibilityBand">
      <div>
        <span class="eyebrow">Works with your current stack</span>
        <h3>Yes, your existing log monitor or alert rule can remain the source.</h3>
        <p>You do not need to move detection into AlertMend first. Keep Datadog log monitors, Grafana alerts, Prometheus Alertmanager routes, CloudWatch alarms, Elastic/OpenSearch alerts, New Relic alerts, uptime checks, or custom webhooks. Add escalation after the alert fires.</p>
      </div>
      <div class="compatibilityPills" aria-label="Compatible alert sources">
        <span>Datadog log monitors</span>
        <span>Grafana / Loki</span>
        <span>Prometheus Alertmanager</span>
        <span>CloudWatch Logs + alarms</span>
        <span>Elastic / OpenSearch</span>
        <span>New Relic</span>
        <span>Uptime monitors</span>
        <span>Custom webhooks</span>
      </div>
    </div>
    <div class="setupGrid">
      <div class="setupCard"><div class="setupIcon">${icon('graph')}</div><h3>Grafana WhatsApp alerts</h3><p>Use Grafana notification policies and contact points to route critical alerts into a WhatsApp and phone call escalation workflow.</p></div>
      <div class="setupCard"><div class="setupIcon">${icon('bell')}</div><h3>Prometheus Alertmanager escalation</h3><p>Keep Alertmanager for grouping and inhibition, then send urgent routes to an escalation endpoint for WhatsApp, calls, and fallback.</p></div>
      <div class="setupCard"><div class="setupIcon">${icon('webhook')}</div><h3>Datadog log monitor escalation</h3><p>Send selected Datadog log monitors, metric monitors, or APM monitors through a webhook so critical incidents can trigger owner-aware WhatsApp alerts and call escalation.</p></div>
      <div class="setupCard"><div class="setupIcon">${icon('cloud')}</div><h3>CloudWatch Logs and alarm escalation</h3><p>Use CloudWatch alarm actions, log metric filters, or SNS to hand off production alarms to an escalation policy with calls only for urgent or missed acknowledgments.</p></div>
      <div class="setupCard"><div class="setupIcon">${icon('call')}</div><h3>Critical alert phone calls</h3><p>Use phone calls for P1 incidents, failed acknowledgments, payment path failures, production outages, and other customer-impacting alerts.</p></div>
      <div class="setupCard"><div class="setupIcon">${icon('whatsapp')}</div><h3>WhatsApp incident alerts</h3><p>Use WhatsApp when responders need impact, service, environment, runbook, recent deploy context, and ack options in one message.</p></div>
    </div>
  </section>

  <section class="sectionBlock" id="why">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('route')}</span>Why escalation fails even when monitoring works</h2>
    <p class="bodyText">Most teams do not have a monitoring problem. They already have dashboards, rules, and alerts. The failure is usually between “alert fired” and “the right human saw it, understood it, acknowledged it, and either fixed it or escalated it.”</p>
    <div class="timelineGrid">
      <div class="timelineCard"><div class="cardIcon">${icon('monitor')}</div><span>Signal</span><h3>Monitoring detects</h3><p>Prometheus, Grafana, Datadog, CloudWatch, uptime checks, or custom jobs detect the symptom.</p></div>
      <div class="timelineCard"><div class="cardIcon">${icon('route')}</div><span>Route</span><h3>Owner selected</h3><p>Severity, service, team, region, business hours, and dedupe key decide the path.</p></div>
      <div class="timelineCard"><div class="cardIcon splitIcon"><span>${icon('whatsapp')}</span><span>${icon('call')}</span></div><span>Escalate</span><h3>WhatsApp + call</h3><p>WhatsApp delivers context; phone call wakes the primary or fallback when needed.</p></div>
      <div class="timelineCard"><div class="cardIcon">${icon('shield')}</div><span>Resolve</span><h3>Action recorded</h3><p>Ack, handoff, runbook, recovery, and audit trail are attached to one incident.</p></div>
    </div>
    <div class="answerBox">
      <strong>Best practice:</strong> do not make every alert a phone call. Phone calls are for urgency. WhatsApp is for context, acknowledgment, approval, and team-visible handoff.
    </div>
  </section>

  <section class="sectionBlock" id="policy">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('shield')}</span>A sane escalation policy template</h2>
    <p class="bodyText">Start with three paths. You can make the rules more sophisticated later, but the first version should be obvious enough that everyone trusts it.</p>
    <div class="policyGrid">
      <div class="policyCard">
        <div class="policyIcon policyIconCritical">${icon('alert')}</div>
        <h3>P1: customer-impacting</h3>
        <ol>
          <li>Send WhatsApp immediately with context.</li>
          <li>Call primary on-call immediately or after 1 minute.</li>
          <li>If no ack in 5 minutes, call secondary.</li>
          <li>If no ack in 10 minutes, escalate to lead/manager.</li>
        </ol>
      </div>
      <div class="policyCard">
        <div class="policyIcon policyIconWhatsapp">${icon('whatsapp')}</div>
        <h3>P2: urgent but not outage</h3>
        <ol>
          <li>Send WhatsApp to primary owner.</li>
          <li>Post to team channel if configured.</li>
          <li>If no ack in 10-15 minutes, call primary.</li>
          <li>Escalate only if impact grows.</li>
        </ol>
      </div>
      <div class="policyCard">
        <div class="policyIcon policyIconQuiet">${icon('inbox')}</div>
        <h3>P3: warning/noise</h3>
        <ol>
          <li>No phone call.</li>
          <li>Route to dashboard, email, Slack, or daily digest.</li>
          <li>Create ticket only if persistent.</li>
          <li>Review thresholds weekly.</li>
        </ol>
      </div>
    </div>
  </section>

  <section class="sectionBlock" id="decision-table">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('route')}</span>What should happen after each alert?</h2>
    <p class="bodyText">This is the part most teams skip. Do not start with the tool. Start with the response rule. A strong escalation path says exactly when to send WhatsApp, when to call, when to create a ticket, and when to stay quiet.</p>
    <div class="decisionTableWrap" role="region" aria-label="Alert escalation decision table">
      <table class="decisionTable">
        <thead>
          <tr>
            <th>Alert type</th>
            <th>Example</th>
            <th>First action</th>
            <th>Call?</th>
            <th>Why</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>P1 outage</strong></td>
            <td>Checkout, login, API, database, or payment path down</td>
            <td>WhatsApp with full context, then call primary</td>
            <td><span class="yesPill">Yes</span></td>
            <td>Customer impact is active and every minute matters.</td>
          </tr>
          <tr>
            <td><strong>Unacknowledged critical</strong></td>
            <td>Critical alert open for 5 minutes without ack</td>
            <td>Call primary, then fallback owner</td>
            <td><span class="yesPill">Yes</span></td>
            <td>The issue may be real, but the current owner has not responded.</td>
          </tr>
          <tr>
            <td><strong>P2 degradation</strong></td>
            <td>Error rate rising, queue lag, disk filling, latency spike</td>
            <td>WhatsApp to owner with runbook and graph link</td>
            <td><span class="maybePill">Maybe</span></td>
            <td>Call only if impact grows or no one acknowledges.</td>
          </tr>
          <tr>
            <td><strong>Warning</strong></td>
            <td>CPU threshold, memory warning, non-prod alert</td>
            <td>Ticket, digest, or team channel</td>
            <td><span class="noPill">No</span></td>
            <td>Calling here creates alert fatigue and distrust.</td>
          </tr>
          <tr>
            <td><strong>Duplicate signal</strong></td>
            <td>Same incident from logs, metrics, APM, and uptime checks</td>
            <td>Group into one incident</td>
            <td><span class="noPill">Not again</span></td>
            <td>One incident should create one escalation thread, not ten calls.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section class="sectionBlock" id="template">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('book')}</span>Copy-paste escalation policy template</h2>
    <p class="bodyText">Use this as a starting point. Replace service names, owners, and times with your own rules. The key idea is simple: WhatsApp delivers context, phone calls enforce urgency, and every path has an acknowledgment deadline.</p>
    <div class="templatePanel">
      <div class="templateHeader">
        <span>${icon('shield')} escalation-policy.yaml</span>
        <span>starter template</span>
      </div>
      <pre><code>service_defaults:
  owner: platform-oncall
  business_hours: Mon-Fri 09:00-18:00
  dedupe_window: 20m

routes:
  - match:
      severity: P1
      environment: production
    notify:
      - whatsapp: primary_owner
      - call: primary_owner
    if_no_ack_after: 5m
    fallback:
      - call: secondary_owner
      - whatsapp: incident_lead
    attach:
      - runbook
      - recent_deploys
      - dashboard
      - previous_incidents

  - match:
      severity: P2
      environment: production
    notify:
      - whatsapp: service_owner
    if_no_ack_after: 15m
    fallback:
      - call: service_owner

  - match:
      severity: warning
    notify:
      - team_channel
    call: never
    create_ticket_if_open_for: 24h</code></pre>
    </div>
    <div class="answerBox">
      <strong>Practical rule:</strong> if a route cannot name the owner, impact, fallback, and runbook, it is not ready for phone calls yet.
    </div>
  </section>

  <section class="sectionBlock" id="tools">
    <div class="decoderHeader">
      <div>
        <span class="eyebrow">Use what you already have</span>
        <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('webhook')}</span>How to wire common monitoring tools</h2>
      </div>
      <p>Pick your current alert source. The implementation changes, but the escalation model stays the same.</p>
    </div>
    <div class="scenarioTabs" role="tablist" aria-label="Monitoring tool escalation scenarios">
      <button class="scenarioTab isActive" type="button" role="tab" aria-selected="true" data-scenario="alertmanager">${icon('bell')}Alertmanager</button>
      <button class="scenarioTab" type="button" role="tab" aria-selected="false" data-scenario="grafana">${icon('graph')}Grafana</button>
      <button class="scenarioTab" type="button" role="tab" aria-selected="false" data-scenario="datadog">${icon('webhook')}Datadog</button>
      <button class="scenarioTab" type="button" role="tab" aria-selected="false" data-scenario="cloudwatch">${icon('cloud')}CloudWatch</button>
      <button class="scenarioTab" type="button" role="tab" aria-selected="false" data-scenario="generic">${icon('inbox')}Webhook/email</button>
    </div>
    <div class="scenarioPanel">
      <div class="scenarioTerminal" aria-live="polite">
        <span class="dim">$ escalation wiring</span>
        <strong data-scenario-output>Prometheus fires HighErrorRate
Alertmanager groups + routes
Webhook receiver sends to AlertMend</strong>
      </div>
      <div class="scenarioMeaning">
        <span class="eyebrow">Pattern</span>
        <h3 data-scenario-title>Use Alertmanager routing to send only actionable alerts to the escalation layer.</h3>
        <p data-scenario-copy>Keep Alertmanager for grouping, inhibition, and routing. Add a webhook receiver for high-urgency routes that need WhatsApp and phone call escalation.</p>
        <pre><code data-scenario-commands>receivers:
- name: alertmend-escalation
  webhook_configs:
  - url: https://api.alertmend.io/webhooks/alertmanager

route:
  receiver: default
  routes:
  - matchers: [severity="critical"]
    receiver: alertmend-escalation</code></pre>
        <p class="scenarioFix"><strong>Rule:</strong> <span data-scenario-fix>Do not send every warning to a call. Send critical, customer-impacting, or unacknowledged alerts into the escalation path.</span></p>
      </div>
    </div>
  </section>

  <section class="sectionBlock" id="message">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon whatsappHeadingIcon">${icon('whatsapp')}</span>What the WhatsApp escalation should say</h2>
    <p class="bodyText">A useful alert is not “CPU high.” It tells the on-call engineer what is broken, why they are being contacted, what happens next, and how to acknowledge.</p>
    <div class="messagePreview" aria-label="Example WhatsApp escalation message">
      <div class="messageHeader"><span>${icon('whatsapp')} WhatsApp escalation</span><span class="severityPill">${icon('call')} Call if no ack</span></div>
      <div class="messageBody">
        <div class="messageBubble">
          <strong>P1: Checkout API down</strong><br>
          Service: checkout-api · Env: production<br>
          Impact: payment attempts failing in us-east-1<br>
          Source: Grafana High5xxRate · 11:42 UTC<br>
          Evidence: 5xx &gt; 12% for 6m, deploy 18m ago<br>
          Runbook: rollback-checkout-api<br>
          Next escalation: call secondary in 5m if no ack
          <div class="buttonRow">
            <span class="replyButton">Acknowledge</span>
            <span class="replyButton">Runbook</span>
            <span class="replyButton">Escalate</span>
          </div>
        </div>
      </div>
    </div>
    <div class="answerBox">
      <strong>Important:</strong> WhatsApp should not be the only record. Keep an incident record, timestamps, acknowledgments, recipients, and resolution notes for audit and learning.
    </div>
  </section>

  <section class="sectionBlock" id="mistakes">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('alert')}</span>Common mistakes that make escalation painful</h2>
    <p class="bodyText">Most escalation systems fail quietly. They technically send notifications, but responders still lose time because the message is vague, the owner is wrong, or the call policy is too noisy.</p>
    <div class="mistakeGrid">
      <div class="mistakeCard"><span class="mistakeIcon">${icon('alert')}</span><h3>Calling on every threshold</h3><p>CPU, memory, or latency thresholds should not automatically become phone calls. Call only when there is real impact, missed acknowledgment, or a clear P1 rule.</p></div>
      <div class="mistakeCard"><span class="mistakeIcon">${icon('route')}</span><h3>No service owner label</h3><p>If the alert does not carry service, team, environment, and owner, escalation becomes guesswork. Add labels before adding calls.</p></div>
      <div class="mistakeCard"><span class="mistakeIcon">${icon('webhook')}</span><h3>Forwarding raw payloads</h3><p>A raw webhook is rarely readable. Convert it into a concise WhatsApp message with impact, evidence, runbook, and next escalation time.</p></div>
      <div class="mistakeCard"><span class="mistakeIcon">${icon('call')}</span><h3>No fallback timeout</h3><p>If nobody acknowledges within the agreed time, the system should escalate automatically. Otherwise a missed page stays missed.</p></div>
      <div class="mistakeCard"><span class="mistakeIcon">${icon('shield')}</span><h3>No audit trail</h3><p>You need to know who was notified, who acknowledged, when fallback happened, and what action was taken.</p></div>
      <div class="mistakeCard"><span class="mistakeIcon">${icon('test')}</span><h3>No regular drills</h3><p>Escalation paths rot. Run a safe drill monthly so phone numbers, schedules, runbooks, and ownership do not surprise you during an outage.</p></div>
    </div>
  </section>

  <section class="sectionBlock" id="testing">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('test')}</span>Test before you trust it at 3 AM</h2>
    <p class="bodyText">Run drills before production paging. A good test proves routing, timing, fallback, message clarity, and audit.</p>
    <div class="stepsGrid">
      <div class="stepCard"><span class="stepIcon">${icon('bell')}</span><h3>Send a test alert</h3><p>Use a safe alert name and mark it as a drill. Confirm it reaches WhatsApp but does not trigger a real incident by accident.</p></div>
      <div class="stepCard"><span class="stepIcon">${icon('call')}</span><h3>Verify call fallback</h3><p>Do not acknowledge the test. Confirm the primary receives a call and the secondary receives fallback only after the configured delay.</p></div>
      <div class="stepCard"><span class="stepIcon">${icon('route')}</span><h3>Check dedupe</h3><p>Fire the same alert multiple times. You should get one incident with updates, not ten calls.</p></div>
      <div class="stepCard"><span class="stepIcon">${icon('shield')}</span><h3>Review the audit trail</h3><p>Confirm timestamps, recipients, ack, escalation, and closure are recorded in one place.</p></div>
    </div>
    <div class="scorecardPanel">
      <h3>Score your escalation path</h3>
      <div class="scorecardGrid">
        <div><strong>&lt; 60s</strong><span>time to notify owner</span></div>
        <div><strong>&lt; 5m</strong><span>fallback if no ack</span></div>
        <div><strong>1</strong><span>incident per real problem</span></div>
        <div><strong>0</strong><span>calls for warnings</span></div>
      </div>
      <p>If you cannot measure these four things, the escalation path is not finished yet.</p>
    </div>
  </section>

  <section class="sectionBlock" id="automation">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('check')}</span>The best lightweight way to add WhatsApp + call escalation</h2>
    <p class="bodyText">AlertMend is a lightweight way to add WhatsApp alerts, phone call fallback, owner routing, runbooks, and audit on top of the monitoring tools you already use. Your Datadog log monitors, Grafana alerts, Prometheus routes, CloudWatch alarms, and custom webhooks can remain the source of truth.</p>
    <div class="automationFlow">
      <h3>From alert to accountable response</h3>
      <div class="automationTrack">
        <div class="automationStep"><span class="flowIcon">${icon('webhook')}</span><strong>Ingest</strong><span>Prometheus, Grafana, Datadog, CloudWatch, uptime monitors, email, or webhook.</span></div>
        <div class="automationArrow">→</div>
        <div class="automationStep"><span class="flowIcon">${icon('route')}</span><strong>Route</strong><span>Map service, owner, severity, environment, and business hours.</span></div>
        <div class="automationArrow">→</div>
        <div class="automationStep"><span class="flowIcon splitFlowIcon"><span>${icon('whatsapp')}</span><span>${icon('call')}</span></span><strong>Escalate</strong><span>WhatsApp first, phone call for P1 or missed acknowledgment.</span></div>
        <div class="automationArrow">→</div>
        <div class="automationStep"><span class="flowIcon">${icon('shield')}</span><strong>Act</strong><span>Attach RCA, runbook, approval, verification, and audit trail.</span></div>
      </div>
    </div>
    <h3 class="sectionTitle subTitle hasIcon"><span class="headingIcon">${icon('alert')}</span>Start with one painful alert</h3>
    <p class="bodyText">Do not boil the ocean. Pick one alert that repeatedly gets missed or wakes the wrong person. Wire that path first: source payload, owner, WhatsApp template, call fallback, acknowledgment, and runbook link.</p>
    <div class="automationCta">
      <p><strong>Want WhatsApp + call escalation on top of your current monitoring?</strong> Bring one real alert from Grafana, Prometheus, Datadog, CloudWatch, or your uptime monitor and we’ll map the escalation path.</p>
      <a class="ctaButton ctaButtonPrimary" href="${calendly}&intent=whatsapp-call-escalation-review" target="_blank" rel="noopener noreferrer">Book a 20-min escalation review →</a>
    </div>
    <p class="bodyText">For enterprise teams, AlertMend can run as a managed or self-hosted control plane, with Slack, WhatsApp, phone call escalation, approval gates, VM/Kubernetes visibility, runbooks, and local-model options where configured.</p>
  </section>

  <section class="sectionBlock" id="sources">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('book')}</span>Primary sources checked</h2>
    <p class="bodyText">This design keeps your existing monitoring layer and adds escalation on top of documented notification and webhook paths.</p>
    <ol class="sourceList">
      <li><a href="https://prometheus.io/docs/alerting/latest/configuration/" target="_blank" rel="noopener noreferrer">Prometheus Alertmanager configuration: routing, receivers, webhooks, grouping, repeat intervals, and time intervals</a></li>
      <li><a href="https://grafana.com/docs/grafana/latest/alerting/fundamentals/notifications/contact-points/" target="_blank" rel="noopener noreferrer">Grafana Alerting contact points and notification policies</a></li>
      <li><a href="https://docs.datadoghq.com/integrations/webhooks/" target="_blank" rel="noopener noreferrer">Datadog webhooks integration</a></li>
      <li><a href="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch_Alarms.html" target="_blank" rel="noopener noreferrer">Amazon CloudWatch alarms and alarm actions</a></li>
      <li><a href="https://whatsappbusiness.com/products/business-platform/" target="_blank" rel="noopener noreferrer">WhatsApp Business Platform</a></li>
    </ol>
  </section>

  <section class="sectionBlock" id="faq">
    <h2 class="sectionTitle hasIcon"><span class="headingIcon">${icon('chat')}</span>FAQ</h2>
    <p class="bodyText">These are the questions teams usually ask when they want WhatsApp alerts, phone call escalation, or an on-call escalation path without ripping out Grafana, Prometheus, Datadog, CloudWatch, PagerDuty, or Opsgenie.</p>
    <div class="faqList">
      ${faqHtml()}
    </div>
  </section>
</article>
`

const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${esc(title)} | AlertMend AI</title>
  <meta name="description" content="${esc(description)}">
  <meta name="keywords" content="${esc(keywords)}">
  <meta name="author" content="${esc(author.name)}">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="${canonical}">
  <link rel="icon" type="image/svg+xml" href="/logos/alertmend-logo.svg">
  <meta property="og:type" content="article">
  <meta property="og:title" content="${esc(h1)}">
  <meta property="og:description" content="${esc(description)}">
  <meta property="og:url" content="${canonical}">
  <meta property="og:image" content="${heroImage}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${esc(h1)}">
  <meta name="twitter:description" content="${esc(description)}">
  <meta name="twitter:image" content="${heroImage}">
  <script type="application/ld+json">${JSON.stringify(blogPosting)}</script>
  <script type="application/ld+json">${JSON.stringify(howToJsonLd)}</script>
  <script type="application/ld+json">${JSON.stringify(faqJsonLd)}</script>
  <style>${CHROME_INLINE_CSS}${AUTHOR_CRED_CSS}</style>
  <link rel="stylesheet" href="/assets/${slug}/styles.css">
</head>
<body>
${buildNavHtml(slug, calendly)}
  <main class="main-container">
    <div class="content-wrapper">
      <div class="main-col">
        ${content}
        ${authorCard()}
        <div class="ctaBox">
          <h2>Want your existing alerts to reach the right person?</h2>
          <p>See how AlertMend can add WhatsApp, phone calls, owner routing, runbooks, and audit on top of the monitoring tools you already use.</p>
          <div class="ctaButtons">
            <a class="ctaButton ctaButtonPrimary" href="${calendly}" target="_blank" rel="noopener noreferrer">Book an escalation review</a>
            <a class="ctaButton ctaButtonSecondary" href="https://app.alertmend.io/signup?service=remediation&source=blog-post&blog_slug=${slug}">Try AlertMend</a>
          </div>
        </div>
      </div>
      ${buildSidebarHtml(related, title)}
    </div>
  </main>
  <script src="/assets/${slug}/script.js"></script>
  <script>
  (function(){
${BLOG_SIGNUP_HANDLER_JS}
  })();
  </script>
</body>
</html>`

writeStaticBlogOutputs(slug, html)
console.log(`✓ Article source root: ${root}`)
