import SEO from '../../components/SEO'
import LegacyDocShell from './LegacyDocShell'
import { ensureUniqueMetaDescription } from '../../utils/descriptionUtils'

export default function SlackAppApprovalPage() {
  const baseDescription = "Learn how to configure a Slack App for approval workflows in AlertMend. Step-by-step guide for setting up Slack integration."
  const uniqueDescription = ensureUniqueMetaDescription(baseDescription, 'documentation', 'slack-app-approval')

  return (
    <LegacyDocShell title="Slack app for approval">
      <SEO
        title="Slack app for approvals | AlertMend Docs"
        description={uniqueDescription}
        keywords="Slack integration, Slack app approval, AlertMend Slack setup, notification configuration"
        canonical="/documentation/slack-app-approval"
      />
<section className="py-12 md:py-16 container-padding">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
<h1 className="text-4xl md:text-5xl font-black text-brand-900 mb-4">
                How to Configure a Slack App for Approval
              </h1>
              <p className="text-xl text-gray-600">
                Step-by-step guide to set up Slack App for approval workflows in AlertMend
              </p>
            </div>

            <div className="prose prose-lg max-w-none">
              <div className="bg-brand-50 border-l-4 border-brand-600 p-6 mb-8 rounded-r-lg">
                <h3 className="text-brand-900 font-bold mb-2">Prerequisites</h3>
                <ul className="text-gray-700 space-y-1">
                  <li>Admin access to your Slack workspace</li>
                  <li>AlertMend account with appropriate permissions</li>
                  <li>Basic understanding of Slack app configuration</li>
                </ul>
              </div>

              <h2 className="text-2xl font-bold text-brand-900 mt-8 mb-4">Step 1: Create a Slack App</h2>
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>Navigate to <a href="https://api.slack.com/apps" target="_blank" rel="noopener noreferrer" className="text-brand-600 hover:underline">api.slack.com/apps</a></li>
                <li>Click "Create New App" and select "From scratch"</li>
                <li>Enter your app name (e.g., "AlertMend") and select your workspace</li>
                <li>Click "Create App" to proceed</li>
              </ol>

              <h2 className="text-2xl font-bold text-brand-900 mt-8 mb-4">Step 2: Configure App Permissions</h2>
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>In the app settings, navigate to "OAuth & Permissions"</li>
                <li>Scroll to "Scopes" section and add the following Bot Token Scopes:
                  <ul className="list-disc list-inside ml-6 mt-2 space-y-1">
                    <li><code className="bg-gray-100 px-2 py-1 rounded">chat:write</code> - Send messages</li>
                    <li><code className="bg-gray-100 px-2 py-1 rounded">channels:read</code> - View channel information</li>
                    <li><code className="bg-gray-100 px-2 py-1 rounded">users:read</code> - View user information</li>
                    <li><code className="bg-gray-100 px-2 py-1 rounded">reactions:write</code> - Add reactions</li>
                  </ul>
                </li>
                <li>Save the changes</li>
              </ol>

              <h2 className="text-2xl font-bold text-brand-900 mt-8 mb-4">Step 3: Install App to Workspace</h2>
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>Click "Install to Workspace" at the top of the OAuth & Permissions page</li>
                <li>Review the permissions and click "Allow"</li>
                <li>Copy the "Bot User OAuth Token" (starts with <code className="bg-gray-100 px-2 py-1 rounded">xoxb-</code>)</li>
              </ol>

              <h2 className="text-2xl font-bold text-brand-900 mt-8 mb-4">Step 4: Configure in AlertMend</h2>
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>Log in to your AlertMend dashboard</li>
                <li>Navigate to Settings → Integrations → Slack</li>
                <li>Paste the Bot User OAuth Token</li>
                <li>Select the channel where approval requests should be sent</li>
                <li>Click "Save" to complete the configuration</li>
              </ol>

              <h2 className="text-2xl font-bold text-brand-900 mt-8 mb-4">Step 5: Test the Integration</h2>
              <ol className="list-decimal list-inside space-y-3 text-gray-700">
                <li>Create a test approval workflow in AlertMend</li>
                <li>Trigger the workflow and verify that approval requests appear in your Slack channel</li>
                <li>Test approving and rejecting requests from Slack</li>
              </ol>

              <div className="bg-violet-50 border-l-4 border-violet-600 p-6 mt-8 rounded-r-lg">
                <h3 className="text-violet-950 font-bold mb-2">💡 Tips</h3>
                <ul className="text-gray-700 space-y-1">
                  <li>Keep your Bot Token secure and never share it publicly</li>
                  <li>Use a dedicated channel for approval requests to keep them organized</li>
                  <li>Set up notifications to ensure timely responses to approval requests</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
    </LegacyDocShell>
  )
}
