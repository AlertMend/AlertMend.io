import SEO from '../components/SEO'
import ent from '../components/enterprise/Enterprise.module.css'
import { Calendar, ArrowRight } from 'lucide-react'
import { useMemo } from 'react'
import { blogPosts, formatDate } from '../utils/blogUtils'
import { getBlogPostPath } from '../utils/staticBlogRegistry'
import { ensureUniqueMetaDescription } from '../utils/descriptionUtils'

/**
 * Blog index page.
 *
 * Re-skinned to match the new homepage design system: near-black + zinc
 * neutrals with a single restrained violet accent (`#7c3aed`). The page
 * uses Tailwind utilities because it's part of the legacy chrome, but
 * every chromatic value has been swapped from the old purple/fuchsia/
 * indigo mix to the new single-hue palette so the blog feels like part
 * of the same site as the homepage rather than a separate product.
 */
/**
 * Curated "most viewed / featured" ordering for the blog index. Higher number
 * is pinned nearer the top. Until real Google Analytics pageview data is wired
 * in (via the GA Data API at build time), this acts as the popularity signal;
 * any post not listed here falls back to date, newest first.
 */
const FEATURED_PRIORITY: Record<string, number> = {
  'bcbs-239-data-quality-controls': 120,
  'data-quality-policy-to-automated-checks': 118,
  'monte-carlo-alternatives': 116,
  'snowflake-data-quality-checks': 114,
  'power-bi-data-quality-impact-analysis': 112,
  'data-freshness-monitoring': 110,
  'datadog-alternatives': 100,
  'pagerduty-alternatives': 98,
  'incident-io-alternatives': 96,
  'gpu-monitoring': 94,
  'best-ai-agent-observability-tools': 92,
  'top-kubernetes-cost-management-solutions': 90,
  'best-1-click-logging-and-metrics-tools': 88,
  'ai-agent-observability-in-production': 86,
  'odoo-monitoring': 84,
  'wordpress-monitoring': 82,
  'gitlab-monitoring': 80,
  'n8n-monitoring': 78,
  'nextcloud-monitoring': 76,
  'jira-confluence-monitoring': 74,
  'metabase-monitoring': 72,
  'mattermost-rocketchat-monitoring': 70,
}

export default function BlogPage() {

  const sortedPosts = useMemo(() => {
    try {
      const posts = blogPosts || []
      if (!Array.isArray(posts) || posts.length === 0) {
        return []
      }
      return [...posts]
        .map(post => {
          let excerpt = ''
          if (post && post.excerpt) {
            if (typeof post.excerpt === 'string') {
              excerpt = post.excerpt.trim()
            } else if (typeof post.excerpt === 'object' && post.excerpt !== null) {
              excerpt = String(post.excerpt).trim()
            }
          }
          return {
            ...post,
            excerpt: excerpt || ''
          }
        })
        .sort((a, b) => {
          const pa = FEATURED_PRIORITY[a.slug] || 0
          const pb = FEATURED_PRIORITY[b.slug] || 0
          if (pa !== pb) return pb - pa
          try {
            const dateA = new Date(a.date || 0).getTime()
            const dateB = new Date(b.date || 0).getTime()
            return dateB - dateA
          } catch {
            return 0
          }
        })
    } catch (error) {
      console.error('Error processing blog posts:', error)
      return []
    }
  }, [])

  const baseDescription = "Practical guides from the AlertMend team on data quality, data governance, Kubernetes, observability and automated fixes."
  const uniqueDescription = ensureUniqueMetaDescription(baseDescription, 'blog-list', 'blog')

  if (!sortedPosts || sortedPosts.length === 0) {
    return (
      <div className="min-h-screen bg-white">
        <SEO
          title="AlertMend Blog: Data Quality, Kubernetes and Observability"
          description={uniqueDescription}
          canonical="/blog"
          keywords="AIOps blog, Kubernetes best practices, infrastructure automation, DevOps insights, SRE articles, cloud-native operations"
        />
        <section className="pt-24 pb-20 md:pb-32 px-4 sm:px-6 lg:px-8 relative overflow-hidden bg-white">
          <div className="max-w-7xl mx-auto text-center">
            <p className="text-zinc-600">Loading posts…</p>
          </div>
        </section>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title="AlertMend Blog: Data Quality, Kubernetes and Observability"
        description={uniqueDescription}
        canonical="/blog"
        keywords="AIOps blog, Kubernetes best practices, infrastructure automation, DevOps insights, SRE articles, cloud-native operations"
      />
      <section className="relative overflow-hidden pt-20 pb-24 md:pt-28 md:pb-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-14 md:mb-16 max-w-3xl">
            <span className={ent.eyebrow}>Blog</span>
            <h1 className="text-4xl md:text-[56px] font-semibold tracking-[-0.03em] leading-[1.05] text-[#0b1220]">
              Guides from the AlertMend team
            </h1>
            <p className="mt-5 text-lg md:text-[19px] text-slate-600 leading-relaxed">
              Practical writing on data quality, data governance, Kubernetes, observability, GPU fleets and automated fixes.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-7">
            {sortedPosts.map((post) => {
              const displayTitle = (post.title && post.title.trim() && post.title !== post.slug) ? post.title : post.slug
              const displayExcerpt = post.excerpt && post.excerpt.length > 0 ? post.excerpt : null
              return (
                <article
                  key={post.slug}
                  className="group relative flex h-full flex-col rounded-lg border border-zinc-200 bg-white p-6 transition-all duration-200 hover:border-zinc-400"
                >
                  <div className="mb-4 flex flex-wrap items-center gap-1.5">
                    <span className="inline-flex items-center rounded-md border border-brand-200 bg-brand-50 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-brand-700">
                      {post.category}
                    </span>
                    {post.tags && post.tags.length > 0 && (
                      <>
                        {post.tags
                          .filter(tag => tag.toLowerCase() !== post.category.toLowerCase())
                          .slice(0, 2)
                          .map((tag, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center rounded-md border border-zinc-200 bg-zinc-50 px-2 py-0.5 text-[11px] font-medium text-zinc-600"
                            >
                              {tag}
                            </span>
                          ))}
                      </>
                    )}
                  </div>
                  <h2 className="mb-3 text-xl md:text-[22px] font-semibold leading-snug tracking-tight text-zinc-950 transition-colors group-hover:text-brand-700">
                    <a href={getBlogPostPath(post.slug)} className="!text-inherit after:absolute after:inset-0 after:content-['']">
                      {displayTitle}
                    </a>
                  </h2>
                  {displayExcerpt ? (
                    <p className="mb-6 line-clamp-3 flex-grow text-[15px] leading-relaxed text-zinc-600">{displayExcerpt}</p>
                  ) : (
                    <p className="mb-6 line-clamp-3 flex-grow text-[15px] leading-relaxed text-zinc-500 italic">
                      Read more about {displayTitle}.
                    </p>
                  )}
                  <div className="mt-auto flex items-center justify-between border-t border-zinc-100 pt-4">
                    <div className="flex items-center gap-2 text-[13px] text-zinc-500">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{formatDate(post.date)}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[13px] font-semibold text-brand-600 transition-colors group-hover:text-brand-700">
                      Read more
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </article>
              )
            })}
          </div>
        </div>
      </section>
    </div>
  )
}
