import { useParams, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import SEO from '../components/SEO'
import BlogSignupForm from '../components/BlogSignupForm'
import { Linkedin, ArrowRight } from 'lucide-react'
import { getBlogPost, formatDate, BlogPost, blogPosts } from '../utils/blogUtils'
import { truncateBlogTitle, truncateH2Heading } from '../utils/titleUtils'
import { generateUniqueMetaDescription } from '../utils/descriptionUtils'
import { mapOldBlogUrlToSlug } from '../utils/blogSlugMapper'
import { normalizeBlogMarkdown } from '../utils/markdownNormalize'
import { getBlogPostPath, isStaticBlog } from '../utils/staticBlogRegistry'
import { attachScrollReveal } from '../hooks/useScrollReveal'
import { calendlyUrl } from '../lib/calendly'

export default function BlogPostDetailPage() {
  const { slug } = useParams<{ slug: string }>()
  const navigate = useNavigate()
  const [post, setPost] = useState<BlogPost | null>(null)
  const [loading, setLoading] = useState(true)
  const [navigating, setNavigating] = useState(false)

  let loadingCanonicalUrl = ''
  if (slug) {
    let cleanSlug = slug.replace(/\.html$/, '')
    cleanSlug = cleanSlug.toLowerCase().replace(/_/g, '-')
    loadingCanonicalUrl = `/blog/${cleanSlug}`
  }

  useEffect(() => {
    if (slug) {
      // Reset loading state when slug changes
      setLoading(true)
      setPost(null)
      setNavigating(false)
      
      // Scroll to top when navigating to a new post
      window.scrollTo({ top: 0, behavior: 'instant' })
      
      // Normalize slug: remove .html extension, then map old URLs (including Chinese characters) to new slugs
      let cleanSlug = slug.replace(/\.html$/, '')
      
      // Try to map old URL format to new slug (handles Chinese characters and legacy formats)
      const mappedSlug = mapOldBlogUrlToSlug(cleanSlug)
      if (mappedSlug) {
        cleanSlug = mappedSlug
      } else {
        // Fallback: convert underscores to hyphens, lowercase
        cleanSlug = cleanSlug.toLowerCase().replace(/_/g, '-')
      }
      
      if (isStaticBlog(cleanSlug)) {
        window.location.replace(`/blog/${cleanSlug}`)
        return
      }

      getBlogPost(cleanSlug).then((data) => {
        setPost(data)
        setLoading(false)
      }).catch(() => {
        setPost(null)
        setLoading(false)
      })
    }
  }, [slug])

  // Blog content loads async (fetch markdown). useScrollReveal runs on route change
  // before the article mounts, so `.reveal` sections stay at opacity:0 unless we
  // re-attach the observer once the post is rendered.
  useEffect(() => {
    if (loading || !post) return undefined;
    let io: IntersectionObserver | undefined;
    const raf = requestAnimationFrame(() => {
      io = attachScrollReveal();
    });
    return () => {
      cancelAnimationFrame(raf);
      io?.disconnect();
    };
  }, [loading, post])

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        {loadingCanonicalUrl && (
          <SEO
            title="Loading..."
            description="Loading blog post..."
            canonical={loadingCanonicalUrl}
          />
        )}
        <div className="pt-32 pb-20 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600 mx-auto mb-4"></div>
            <p className="text-zinc-600">Loading post...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-white">
        <div className="pt-32 pb-20 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-zinc-950 mb-4">Post Not Found</h1>
            <button
              onClick={() => navigate('/blog')}
              className="text-brand-600 hover:text-brand-700 underline"
            >
              Return to Blog
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Calculate read time (rough estimate: 200 words per minute)
  const calculateReadTime = (content: string) => {
    const words = content.split(/\s+/).length
    const minutes = Math.ceil(words / 200)
    return `${minutes} min read`
  }

  // Get related posts (prioritize same category, then other posts, excluding current post)
  const sameCategoryPosts = blogPosts
    .filter(p => p.category === post.category && p.slug !== post.slug)
    .slice(0, 3)
  
  const otherPosts = blogPosts
    .filter(p => p.category !== post.category && p.slug !== post.slug)
    .slice(0, 7)
  
  // Combine: 3 from same category + 7 from other categories = 10 total
  const relatedPosts = [...sameCategoryPosts, ...otherPosts].slice(0, 10)

  const readTime = post.content ? calculateReadTime(post.content) : '5 min read'
  const blogPostUrl = `/blog/${post.slug}`
  
  // Use original title for display (no modifications)
  const displayTitle = post.title
  const displayContent = normalizeBlogMarkdown(post.content || '')
  const authorName = post.author || 'AlertMend Team'
  const authorInitial = authorName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase() || 'A'
  const structuredAuthor = post.authorLinkedin
    ? {
        "@type": "Person",
        "name": authorName,
        "url": post.authorLinkedin,
        "sameAs": [post.authorLinkedin]
      }
    : {
        "@type": "Person",
        "name": authorName
      }
  
  // Truncate title to 30-60 characters for SEO (use original title)
  const seoTitle = truncateBlogTitle(post.title)
  
  // Generate unique meta description for SEO (50-160 characters)
  const metaDescription = generateUniqueMetaDescription(
    post.title,
    post.excerpt,
    displayContent,
    post.category
  )

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoTitle}
        description={metaDescription}
        keywords={post.keywords || `${post.category}, AlertMend, AIOps, Kubernetes, DevOps`}
        canonical={blogPostUrl}
        ogImage="https://www.alertmend.io/og-image.jpg"
        ogType="article"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          "headline": seoTitle,
          "description": metaDescription,
          "image": "https://www.alertmend.io/og-image.jpg",
          "datePublished": post.date,
          "dateModified": post.date,
          "author": structuredAuthor,
          "publisher": {
            "@type": "Organization",
            "name": "AlertMend",
            "logo": {
              "@type": "ImageObject",
              "url": "https://alertmend.io/logos/alertmend-logo.svg"
            }
          },
          "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": `https://www.alertmend.io${blogPostUrl}`
          },
          "articleSection": post.category
        }}
        breadcrumbData={{
          items: [
            { label: 'Blog', path: '/blog' },
            { label: post.title }
          ]
        }}
        extraStructuredData={undefined}
      />
      <main className="pt-10 md:pt-12">
        <article className="pb-8 md:pb-12 container-padding">
          <div className="max-w-7xl mx-auto">
            <div>

            <div className="grid lg:grid-cols-12 gap-8">
              {/* Main Content Area (70%) */}
              <div className="lg:col-span-8">
                <div className="flex gap-6">
                  {/* Content */}
                  <div className="flex-1">
                    {/* Header */}
                    <header className="mb-8">
                      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-zinc-950 mb-6 leading-tight tracking-tight">
                        {displayTitle}
                      </h1>
                      
                      {/* Author Info */}
                      <div className="flex items-center gap-4 mb-4">
                        {post.authorImage ? (
                          <div className="relative w-12 h-12 flex-shrink-0">
                            <img
                              src={post.authorImage}
                              alt={authorName}
                              className="w-12 h-12 rounded-full object-cover border border-zinc-200 shadow-sm bg-zinc-50"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.style.display = 'none'
                                const fallback = target.parentElement?.querySelector('.author-initial-fallback') as HTMLElement
                                if (fallback) fallback.style.display = 'flex'
                              }}
                            />
                            <div
                              className="author-initial-fallback absolute inset-0 rounded-full bg-zinc-900 items-center justify-center text-white font-semibold"
                              style={{ display: 'none' }}
                            >
                              {authorInitial}
                            </div>
                          </div>
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-zinc-900 flex items-center justify-center text-white font-semibold flex-shrink-0">
                            {authorInitial}
                          </div>
                        )}
                        <div>
                          <div className="font-semibold text-zinc-900">{authorName}</div>
                          {post.authorCredLine && (
                            <div className="text-sm text-zinc-600 leading-snug">{post.authorCredLine}</div>
                          )}
                          <div className="text-sm text-zinc-500 mt-0.5">{readTime} • {formatDate(post.date)}</div>
                        </div>
                      </div>

                    </header>

                    {/* Content */}
                    <div className="prose prose-lg max-w-none">
                      <div className="text-gray-800 leading-7">
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            h1: ({ node, ...props }) => <h2 className="text-3xl md:text-4xl font-bold text-zinc-950 mt-10 mb-5 first:mt-0 leading-tight tracking-tight" {...props} />,
                            h2: ({ node, children, ...props }: any) => {
                              // Extract text from children (can be string, array, or ReactNode)
                              let headingText = ''
                              if (typeof children === 'string') {
                                headingText = children
                              } else if (Array.isArray(children)) {
                                headingText = children
                                  .map((child: any) => {
                                    if (typeof child === 'string') return child
                                    if (typeof child === 'object' && child?.props?.children) {
                                      return typeof child.props.children === 'string' 
                                        ? child.props.children 
                                        : String(child.props.children)
                                    }
                                    return String(child)
                                  })
                                  .join('')
                              } else if (children) {
                                headingText = String(children)
                              }
                              const truncatedText = truncateH2Heading(headingText.trim())
                              return <h2 className="text-2xl md:text-3xl font-bold text-zinc-950 mt-10 mb-5 leading-tight tracking-tight" {...props}>{truncatedText}</h2>
                            },
                            h3: ({ node, ...props }) => <h3 className="text-xl md:text-2xl font-bold text-zinc-950 mt-8 mb-4 leading-tight tracking-tight" {...props} />,
                            p: ({ node, ...props }) => <p className="text-zinc-700 leading-7 mb-6 text-lg" {...props} />,
                            ul: ({ node, ...props }) => <ul className="list-disc mb-6 space-y-3 text-zinc-700 ml-6 text-lg leading-7" {...props} />,
                            ol: ({ node, ...props }) => <ol className="list-decimal mb-6 space-y-3 text-zinc-700 ml-6 text-lg leading-7" {...props} />,
                            li: ({ node, ...props }) => <li className="text-zinc-700 leading-7" {...props} />,
                            blockquote: ({ node, ...props }) => <blockquote className="border-l-2 border-brand-500 bg-brand-50/40 pl-5 pr-4 py-2 italic text-zinc-700 my-8 text-lg leading-7 rounded-r-md" {...props} />,
                            code: ({ node, className, children, ...props }: any) => {
                              const isInline = !className
                              return isInline ? (
                                <code className="bg-brand-50 text-brand-700 border border-brand-100 px-1.5 py-0.5 rounded text-[0.92em] font-mono" {...props}>{children}</code>
                              ) : (
                                <code className={className} {...props}>{children}</code>
                              )
                            },
                            pre: ({ node, ...props }) => <pre className="bg-zinc-950 text-zinc-100 p-5 rounded-lg overflow-x-auto my-6 text-sm leading-6" {...props} />,
                            a: ({ node, ...props }) => <a className="text-brand-600 hover:text-brand-700 underline underline-offset-2" {...props} />,
                            strong: ({ node, ...props }) => <strong className="font-bold text-zinc-950" {...props} />,
                            em: ({ node, ...props }) => <em className="italic text-zinc-700" {...props} />,
                            hr: ({ node, ...props }) => <hr className="my-8 border-zinc-200" {...props} />,
                            img: ({ node, ...props }) => <img className="rounded-lg my-8 w-full" {...props} />,
                            table: ({ node, ...props }) => (
                              <div className="table-wrapper">
                                <table {...props} />
                              </div>
                            ),
                          }}
                        >
                          {displayContent}
                        </ReactMarkdown>
                      </div>
                    </div>

                    <div className="mt-12 pt-8 border-t border-zinc-200">
                      <p className="text-zinc-700 text-lg leading-7 mb-3">
                        Ready to go from signal to root cause to an approved fix?
                      </p>
                      <p className="text-zinc-700 text-lg leading-7 mb-6">
                        See how AlertMend unifies observability, runs evidence-backed AI RCA, and remediates only after approval, across Kubernetes, VMs, and cloud.{' '}
                        <button
                          onClick={() => window.open(calendlyUrl('blog-post'), '_blank')}
                          className="text-brand-600 hover:text-brand-700 font-semibold underline underline-offset-2 inline-flex items-center gap-1"
                        >
                          Book a demo.
                          <ArrowRight className="h-4 w-4" />
                        </button>
                      </p>
                    </div>

                    {/* Horizontal Separator */}
                    <hr className="my-8 border-zinc-200" />

                     {/* Arvind Rajpurohit Profile Section */}
                     <div className="flex flex-col sm:flex-row gap-6 pb-8">
                       {/* Profile Picture */}
                       <div className="flex-shrink-0 relative w-32 h-32">
                         <img
                           src="/logos/arvind.jpeg"
                           alt="Arvind Rajpurohit"
                           className="w-32 h-32 rounded-lg object-cover border border-zinc-200"
                           style={{ display: 'block', position: 'relative', zIndex: 10 }}
                           onError={(e) => {
                             const target = e.target as HTMLImageElement
                             target.style.display = 'none'
                             const placeholder = target.parentElement?.querySelector('.profile-placeholder-arvind') as HTMLElement
                             if (placeholder) {
                               placeholder.style.display = 'flex'
                             }
                           }}
                           onLoad={(e) => {
                             const target = e.target as HTMLImageElement
                             const placeholder = target.parentElement?.querySelector('.profile-placeholder-arvind') as HTMLElement
                             if (placeholder) {
                               placeholder.style.display = 'none'
                             }
                           }}
                         />
                         <div 
                           className="profile-placeholder-arvind w-32 h-32 rounded-lg bg-zinc-100 border border-zinc-200 flex items-center justify-center text-zinc-700 font-bold text-2xl absolute top-0 left-0"
                           style={{ display: 'none', zIndex: 0 }}
                         >
                           AR
                         </div>
                       </div>

                       {/* Profile Content */}
                       <div className="flex-1">
                         <h3 className="text-2xl font-bold text-zinc-950 mb-2">
                           Arvind Rajpurohit
                         </h3>
                         <p className="text-brand-600 font-semibold mb-4">Co-Founder &amp; CEO</p>
                         <div className="text-zinc-700 leading-7 space-y-4 mb-4">
                           <p>
                             Arvind Rajpurohit - 15+ years in Kubernetes and infrastructure automation. Former DevOps Lead at Roambee and Customer Success Engineer at Shoreline.io (acquired by NVIDIA). Helped teams reach 99.97% uptime, reduce costs by 50%, and cut manual work by 90%.
                           </p>
                           <p>
                             As CEO of AlertMend, building production ops where AI explains incidents and teams approve the fix.
                           </p>
                         </div>
                         {/* LinkedIn Icon */}
                         <a
                           href="https://www.linkedin.com/in/arvind-rajpurohit-4a332523/"
                          aria-label="Arvind Rajpurohit on LinkedIn"
                           target="_blank"
                           rel="noopener noreferrer"
                           className="inline-flex items-center text-zinc-500 hover:text-brand-600 transition-colors"
                         >
                           <Linkedin className="h-5 w-5" />
                         </a>
                       </div>
                     </div>
                   </div>
                 </div>
                </div>

              {/* Sidebar (30%) */}
              <div className="lg:col-span-4">
                <div className="space-y-6 sticky top-24">
                  {/* Email Signup */}
                  <div className="bg-zinc-50 rounded-lg p-6 border border-zinc-200">
                    <h3 className="text-lg font-bold text-zinc-950 mb-4">Receive blog and product updates</h3>
                    <BlogSignupForm blogTitle={post.title} />
                  </div>

                  {/* Related Content */}
                  {relatedPosts.length > 0 && (
                    <div className="bg-zinc-50 rounded-lg p-6 border border-zinc-200 mb-6">
                      <h3 className="text-[11px] font-bold text-zinc-500 uppercase tracking-[0.12em] mb-4">Related content</h3>
                      <ul className="space-y-3">
                        {relatedPosts.map((relatedPost) => (
                          <li key={relatedPost.slug}>
                            <a
                              href={getBlogPostPath(relatedPost.slug)}
                              onClick={(e) => {
                                e.preventDefault()
                                e.stopPropagation()
                                if (!navigating) {
                                  setNavigating(true)
                                  if (isStaticBlog(relatedPost.slug)) {
                                    window.location.assign(getBlogPostPath(relatedPost.slug))
                                  } else {
                                    navigate(getBlogPostPath(relatedPost.slug))
                                  }
                                }
                              }}
                              className="text-left text-zinc-700 hover:text-brand-600 text-sm leading-relaxed cursor-pointer block transition-colors"
                            >
                              {relatedPost.title}
                            </a>
                          </li>
                        ))}
                      </ul>
                      <a
                        href="/blog"
                        onClick={(e) => {
                          e.preventDefault()
                          e.stopPropagation()
                          if (!navigating) {
                            setNavigating(true)
                            navigate('/blog')
                          }
                        }}
                        className="mt-4 text-brand-600 hover:text-brand-700 text-sm font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        View all posts
                        <ArrowRight className="h-4 w-4" />
                      </a>
                    </div>
                  )}

                  {/* Additional Internal Links */}
                  <div className="bg-white rounded-lg p-6 border border-zinc-200">
                    <h3 className="text-[11px] font-bold text-zinc-500 uppercase tracking-[0.12em] mb-4">Explore AlertMend</h3>
                    <ul className="space-y-2 text-sm">
                      <li>
                        <a href="/" className="text-zinc-700 hover:text-brand-600 transition-colors">Home</a>
                      </li>
                      <li>
                        <a href="/auto-remediation" className="text-zinc-700 hover:text-brand-600 transition-colors">Automated Incident Remediation</a>
                      </li>
                      <li>
                        <a href="/kubernetes-management" className="text-zinc-700 hover:text-brand-600 transition-colors">Kubernetes Management</a>
                      </li>
                      <li>
                        <a href="/on-call-management" className="text-zinc-700 hover:text-brand-600 transition-colors">On-Call Management</a>
                      </li>
                      <li>
                        <a href="/kubernetes-cost-optimization" className="text-zinc-700 hover:text-brand-600 transition-colors">Cost Optimization</a>
                      </li>
                      <li>
                        <a href="/case-studies" className="text-zinc-700 hover:text-brand-600 transition-colors">Case Studies</a>
                      </li>
                      <li>
                        <a href="/pricing" className="text-zinc-700 hover:text-brand-600 transition-colors">Pricing</a>
                      </li>
                      <li>
                        <a href="/blog" className="text-zinc-700 hover:text-brand-600 transition-colors">All Blog Posts</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
        </article>
      </main>
    </div>
  )
}
