import { useNavigate } from 'react-router-dom'
import { Calendar, ArrowRight } from 'lucide-react'
import { blogPosts, formatDate } from '../utils/blogUtils'
import { getBlogPostPath, isStaticBlog } from '../utils/staticBlogRegistry'

/**
 * Latest blog posts strip.
 *
 * Lives on legacy pages (older marketing routes still use the original
 * `LatestBlogPosts` block). Re-skinned to match the new homepage's
 * near-black + zinc + single-violet system so the legacy pages don't
 * fight with the redesigned homepage chrome.
 */
export default function LatestBlogPosts() {
  const navigate = useNavigate()

  const latestPosts = [...blogPosts]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 6)

  return (
    <section id="latest-blog-posts" className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-brand-50 border border-brand-200 text-brand-700 rounded-full text-[11px] font-bold uppercase tracking-[0.16em] mb-5">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-600 shadow-[0_0_0_3px_rgba(124, 58, 237,0.14)]" />
            Latest insights
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-zinc-950 mb-4 tracking-tight">
            Latest Blog Posts
          </h2>
          <p className="text-lg md:text-xl text-zinc-500 max-w-2xl mx-auto leading-relaxed">
            Stay updated with the latest trends, best practices, and insights in AIOps and infrastructure management.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {latestPosts.map((post) => {
            const displayTitle = post.title && post.title !== post.slug ? post.title : post.title || post.slug
            return (
              <article
                key={post.slug}
                onClick={() => {
                  if (isStaticBlog(post.slug)) {
                    window.location.assign(getBlogPostPath(post.slug))
                  } else {
                    navigate(getBlogPostPath(post.slug))
                  }
                }}
                className="group bg-white rounded-lg p-6 border border-zinc-200 hover:border-zinc-300 hover:shadow-[0_1px_2px_rgba(9,9,11,0.04),0_12px_24px_-16px_rgba(9,9,11,0.16)] transition-all duration-200 cursor-pointer flex flex-col h-full hover:-translate-y-0.5"
              >
                <div className="flex items-center gap-2 flex-wrap mb-3">
                  <div className="inline-block px-2 py-0.5 bg-brand-50 border border-brand-200 text-brand-700 rounded-md text-[11px] font-semibold uppercase tracking-wider">
                    {post.category}
                  </div>
                </div>
                <h3 className="text-lg md:text-xl font-bold text-zinc-950 mb-3 leading-tight tracking-tight group-hover:text-brand-700 transition-colors">
                  {displayTitle}
                </h3>
                <p className="text-zinc-600 mb-4 leading-relaxed line-clamp-2 flex-grow text-sm">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between pt-4 border-t border-zinc-100">
                  <div className="flex items-center gap-2 text-zinc-500 text-xs">
                    <Calendar className="h-3 w-3" />
                    <span>{formatDate(post.date)}</span>
                  </div>
                  <div className="text-brand-600 group-hover:text-brand-700 font-semibold text-xs flex items-center gap-1 transition-colors">
                    Read More
                    <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </article>
            )
          })}
        </div>

        <div className="text-center">
          <button
            onClick={() => navigate('/blog')}
            className="inline-flex items-center gap-2 bg-zinc-950 text-white px-7 py-3 rounded-lg font-semibold hover:bg-zinc-900 transition-colors shadow-[0_1px_2px_rgba(9,9,11,0.16)] hover:shadow-[0_4px_12px_-4px_rgba(9,9,11,0.24)]"
          >
            View All Blog Posts
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  )
}
