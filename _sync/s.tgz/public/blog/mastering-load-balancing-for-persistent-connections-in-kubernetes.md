---
title: "Load Balancing Persistent Connections Guide"
excerpt: "Learn why Kubernetes struggles with long-lived connections and how to architect reliable, scalable load balancing for gRPC, WebSockets, and database sessions."
date: "2025-07-28"
category: "Kubernetes"
author: "Arvind Rajpurohit"
keywords: "Kubernetes load balancing, persistent connections, gRPC load balancing, WebSocket load balancing, Kubernetes services, kube-proxy, headless services, service mesh, Istio, Envoy, long-lived connections, database connection pooling, Kubernetes networking"
---

# Mastering Load Balancing for Persistent Connections in Kubernetes

Kubernetes revolutionized application deployment with powerful primitives like Deployments and Services. While it handles stateless workloads well, things get tricky when working with long-lived connections such as gRPC, WebSockets, and database sessions.

In this blog, we’ll explore why Kubernetes’ default networking model doesn’t scale well with persistent connections and what alternatives you should consider for efficient traffic distribution.

---

## The Problem with Long-Lived Connections

Kubernetes Services abstract access to Pods behind a stable IP. For stateless HTTP calls, this works seamlessly. Each request maps to a new connection, and kube-proxy’s iptables or IPVS rules randomly assign a backend Pod.

But with long-lived TCP connections - WebSockets, gRPC streams, AMQP queues, or persistent DB sessions - the connection stays pinned to a single Pod, breaking the illusion of balanced load.

---

## How Kubernetes Services Work (Recap)

Kubernetes Services don’t maintain a listener or process on the virtual IP. Instead:

- `kube-controller-manager` allocates the Service IP
- `kube-proxy` configures `iptables` or `IPVS` rules on every node
- These rules forward traffic to Pods based on selectors

> But the rules are only evaluated at connection **start**. Reused connections skip them entirely.

---

## Why Load Balancing Breaks for Persistent Connections

**Example:** Frontend Pod connects to a backend Service with 3 replicas using HTTP keep-alive.

1. First request → kube-proxy picks Pod A
2. TCP connection stays open
3. All future requests go only to Pod A

Even if Pods B and C are healthy, they won’t receive traffic unless the frontend opens new connections.

---

## Solutions: Smarter Load Distribution

### 1. Client-Side Load Balancing

Your app retrieves Pod IPs via a **Headless Service** and:

- Maintains a connection pool to each Pod
- Uses round-robin or least-used logic
- Periodically refreshes the Pod list

> Libraries like gRPC (Java/Python) or JDBC (`loadBalanceHosts=true`) support this natively.

### 2. Service Mesh or Proxy Layer

Use a smart sidecar/proxy to abstract the balancing:

- **Envoy, Istio** → gRPC, HTTP/2
- **pgpool** → PostgreSQL
- **HAProxy, Traefik** → WebSockets, TCP

These proxies keep the client connection alive while distributing traffic among backends.

---

## Common Scenarios & Recommended Tools

| **Protocol**| **Problem**                     | **Suggested Tool**     |
|:------------|:--------------------------------|:-----------------------|
| HTTP/2      | Persistent streams              | Envoy, Istio, NGINX    |
| gRPC        | Long-lived bidirectional streams| Envoy, client logic    |
| WebSockets  | Single TCP tunnel               | HAProxy, NGINX, sticky |
| PostgreSQL  | Persistent DB sessions          | JDBC, pgpool           |
| MongoDB     | Static connections              | Mongos, pooled clients |

---

## When This Matters Most

Persistent connection imbalance hurts **when:**

- Fewer clients than backend Pods
- Clients stick to the first Pod they connect to
- Idle replicas waste resources

> If clients > servers, natural spread occurs. But reverse leads to underutilization.

---

## Advanced Option: Headless Services with Connection Pools

Headless Services (`clusterIP: None`) return **all Pod IPs** via DNS. This allows clients to:

- Resolve all endpoints
- Open persistent connections to each
- Rebalance as Pods scale

This adds app complexity but offers full control ideal for Kafka consumers, DB poolers, etc.

---

## Conclusion

Kubernetes is powerful, but it’s not magic. Default Service behavior isn't enough for persistent connections.

- Use a **Service Mesh**
- Move **load-balancing logic to the client**
- Or add a **smart proxy** in the path

Choose what suits your stack and unlock scalable, balanced traffic across your cluster.
